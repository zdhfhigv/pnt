import React from 'react'

export default function Loading() {
  return (
    <div style={{color: '#e88f19' , padding:"5px"}}>
        در حال بارگذاری...
    </div>
  )
}
